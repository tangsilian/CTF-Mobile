def dec_string(enc_data):
    ret_len = len(enc_data)
    ret = ""
    chr1 = None
    chr2 = None
    """
        *result =
        ~(( ~ cur_int&0xff | ((unsigned    __int16)(cur_int & 0xFF00) >> 8)) & (~((unsigned    __int16)(cur_int & 0xFF00) >> 8) | cur_int));
        result[1] = HIBYTE(cur_int) ^ ((cur_int & 0xFF0000) >> 16);
    """
    for i in range(ret_len):
        cur_int = enc_data[i]
        chr1 = (~(((~cur_int & 0xff) | ((cur_int & 0xff00) >> 8)) & ((~(cur_int & 0xff00) >> 8) | cur_int))) & 0xff
        chr2 = ((cur_int & 0xff000000) >> 24) ^ ((cur_int & 0xff0000) >> 16)
        ret += chr(chr1)
        ret += chr(chr2)
    return ret



pDecode = 0x680

for x in XrefsTo(pDecode,flags = 0):
    #MakeCode((x.frm & 0xFFFFFFFE)); 
    addr = x.frm
    
    print hex(addr)
    while True:
        addr = PrevHead(addr)
        if "esp" in GetOpnd(addr,0):
            if "x" not in  GetOpnd(addr,1):
                index = GetOperandValue(addr,1)
                break
    
    dict = []
    count = 0
    while count < index:
        addr = PrevHead(addr)
        if "esp" in GetOpnd(addr,0):
            dict.append(GetOperandValue(addr,1))
            count += 1

    MakeComm(x.frm,dec_string(dict))
            
        